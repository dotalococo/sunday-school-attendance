# 部署指南 - 聖谷兒童主日學智慧系統

本指南將協助您將基於Canva設計的智慧點名系統部署到網路上，讓所有使用者都能存取。

## 🎯 部署選項概覽

| 平台 | 費用 | 難度 | 推薦度 | 特色 |
|------|------|------|--------|------|
| **Netlify** | 免費 | ⭐ | ⭐⭐⭐⭐⭐ | 拖拉部署，自動HTTPS |
| **Vercel** | 免費 | ⭐⭐ | ⭐⭐⭐⭐ | 快速部署，優秀效能 |
| **GitHub Pages** | 免費 | ⭐⭐⭐ | ⭐⭐⭐ | 與GitHub整合 |

## 🚀 方法一：Netlify部署（推薦）

### 為什麼選擇Netlify？
- ✅ **完全免費**：無需信用卡
- ✅ **拖拉部署**：最簡單的部署方式
- ✅ **自動HTTPS**：安全連線，支援相機功能
- ✅ **全球CDN**：快速載入
- ✅ **自動更新**：檔案更新後自動重新部署

### 步驟一：準備檔案
1. **建立專案資料夾**
   ```
   sunday-school-attendance/
   ├── index.html
   ├── qr-generator.html
   ├── css/
   │   └── style.css
   ├── js/
   │   ├── main.js
   │   └── qr-generator.js
   └── README.md
   ```

2. **檢查檔案完整性**
   - [ ] 所有HTML檔案都在根目錄
   - [ ] CSS和JS檔案在對應子資料夾
   - [ ] 檔案路徑正確無誤
   - [ ] 沒有中文檔名或特殊字符

### 步驟二：部署到Netlify
1. **前往Netlify**
   - 開啟 [https://netlify.com](https://netlify.com)
   - 點擊「Sign up」註冊帳號（可用GitHub、GitLab或Email）

2. **拖拉部署**
   - 登入後會看到控制台
   - 找到「Want to deploy a new site without connecting to Git?」區域
   - 將您的 `sunday-school-attendance` 資料夾直接拖拉到虛線框中

3. **等待部署完成**
   - Netlify會自動處理檔案上傳
   - 通常需要1-2分鐘
   - 完成後會顯示隨機生成的網址

4. **取得網站網址**
   ```
   您的網站已上線！
   https://amazing-curie-123456.netlify.app
   ```

### 步驟三：自訂網域（可選）
1. **在Netlify控制台中**
   - 點擊「Site settings」
   - 選擇「Domain management」
   - 點擊「Add custom domain」

2. **設定自訂網域**
   - 輸入您的網域名稱（如：sunday-school.yourchurch.org）
   - 按照指示設定DNS記錄
   - Netlify會自動提供SSL憑證

## 🔧 方法二：Vercel部署

### 步驟一：GitHub準備
1. **建立GitHub帳號**
   - 前往 [https://github.com](https://github.com)
   - 註冊免費帳號

2. **建立新倉庫**
   - 點擊「New repository」
   - 倉庫名稱：`sunday-school-attendance`
   - 設定為Public
   - 勾選「Add a README file」

3. **上傳檔案**
   - 點擊「uploading an existing file」
   - 拖拉所有專案檔案
   - 填寫提交訊息：「Initial commit」
   - 點擊「Commit changes」

### 步驟二：連接Vercel
1. **前往Vercel**
   - 開啟 [https://vercel.com](https://vercel.com)
   - 使用GitHub帳號登入

2. **匯入專案**
   - 點擊「New Project」
   - 選擇您的GitHub倉庫
   - 點擊「Import」

3. **設定專案**
   - Framework Preset: 選擇「Other」
   - Build Command: 留空
   - Output Directory: 留空
   - Install Command: 留空

4. **部署**
   - 點擊「Deploy」
   - 等待部署完成
   - 取得自動生成的網址

## 📱 方法三：GitHub Pages部署

### 步驟一：上傳到GitHub
（參考方法二的GitHub準備步驟）

### 步驟二：啟用GitHub Pages
1. **在倉庫頁面**
   - 點擊「Settings」標籤
   - 滾動到「Pages」區段

2. **設定Pages**
   - Source: 選擇「Deploy from a branch」
   - Branch: 選擇「main」
   - Folder: 選擇「/ (root)」
   - 點擊「Save」

3. **等待部署**
   - 通常需要5-10分鐘
   - 完成後會顯示網址：
   ```
   https://yourusername.github.io/sunday-school-attendance/
   ```

## 🔒 HTTPS設定重要性

### 為什麼需要HTTPS？
- 📱 **相機權限**：現代瀏覽器要求HTTPS才能存取相機
- 🔒 **資料安全**：加密傳輸，保護使用者隱私
- 🚀 **效能優化**：支援HTTP/2，載入更快
- 📈 **SEO友好**：搜尋引擎偏好HTTPS網站

### 檢查HTTPS狀態
1. **網址列檢查**
   - 確保網址以 `https://` 開頭
   - 看到綠色鎖頭圖示

2. **功能測試**
   - 嘗試開啟QR碼掃描功能
   - 確認相機權限請求正常

## 📊 效能優化建議

### 檔案優化
1. **壓縮圖片**
   - 使用WebP格式
   - 壓縮PNG/JPG檔案

2. **最小化CSS/JS**
   ```bash
   # 使用線上工具或命令列工具
   npm install -g clean-css-cli uglify-js
   cleancss style.css -o style.min.css
   uglifyjs main.js -o main.min.js
   ```

3. **啟用快取**
   - 在Netlify中自動啟用
   - 設定適當的快取標頭

### 載入速度測試
1. **使用測試工具**
   - [PageSpeed Insights](https://pagespeed.web.dev/)
   - [GTmetrix](https://gtmetrix.com/)
   - [WebPageTest](https://www.webpagetest.org/)

2. **目標指標**
   - 首次內容繪製 < 2秒
   - 最大內容繪製 < 3秒
   - 累積版面偏移 < 0.1

## 🌐 自訂網域設定

### 購買網域
1. **推薦註冊商**
   - [Namecheap](https://www.namecheap.com/)
   - [GoDaddy](https://www.godaddy.com/)
   - [Cloudflare](https://www.cloudflare.com/)

2. **網域建議**
   - `yourchurch-sunday.com`
   - `sunday.yourchurch.org`
   - `kids.yourchurch.org`

### DNS設定
1. **Netlify設定**
   ```
   類型: CNAME
   名稱: www (或您的子網域)
   值: your-site.netlify.app
   ```

2. **Vercel設定**
   ```
   類型: CNAME
   名稱: www
   值: cname.vercel-dns.com
   ```

## 📱 行動裝置優化

### 測試清單
- [ ] **iPhone Safari**：相機功能正常
- [ ] **Android Chrome**：QR碼掃描順暢
- [ ] **iPad**：版面配置適當
- [ ] **小螢幕手機**：按鈕大小合適

### 優化建議
1. **觸控友好**
   - 按鈕最小44px × 44px
   - 適當的間距避免誤觸

2. **載入優化**
   - 壓縮圖片
   - 延遲載入非關鍵資源

3. **離線支援**
   - 實作Service Worker
   - 快取關鍵資源

## 🔧 故障排除

### 部署失敗
**問題**：檔案上傳後網站無法正常顯示
**解決方案**：
1. 檢查檔案結構是否正確
2. 確認index.html在根目錄
3. 檢查檔案路徑大小寫
4. 查看部署日誌錯誤訊息

### 相機功能無效
**問題**：QR碼掃描無法啟動相機
**解決方案**：
1. 確認網站使用HTTPS
2. 檢查瀏覽器相機權限
3. 測試不同瀏覽器
4. 確認QR Scanner庫載入成功

### 載入速度慢
**問題**：網站開啟速度過慢
**解決方案**：
1. 壓縮圖片和檔案
2. 使用CDN加速
3. 優化CSS和JavaScript
4. 檢查網路連線

## 📈 監控與維護

### 網站監控
1. **正常運行監控**
   - 使用 [UptimeRobot](https://uptimerobot.com/) 免費監控
   - 設定故障通知

2. **效能監控**
   - Google Analytics（可選）
   - 定期效能測試

### 定期維護
1. **每週檢查**
   - 測試主要功能
   - 檢查錯誤日誌
   - 備份重要資料

2. **每月更新**
   - 更新第三方庫
   - 檢查安全性
   - 優化效能

## 🎉 部署完成檢查清單

部署完成後，請逐一檢查以下項目：

### 基本功能
- [ ] 網站可正常開啟
- [ ] 所有頁面連結正常
- [ ] 響應式設計在各裝置正常
- [ ] HTTPS憑證有效

### 核心功能
- [ ] 新朋友報到表單可提交
- [ ] QR碼掃描功能正常
- [ ] QR碼生成器可使用
- [ ] 點數查詢功能正常
- [ ] 資料儲存和讀取正常

### 效能檢查
- [ ] 首頁載入時間 < 3秒
- [ ] 圖片正常顯示
- [ ] 字體載入正常
- [ ] 動畫效果流暢

### 安全性檢查
- [ ] HTTPS連線正常
- [ ] 相機權限請求正常
- [ ] 沒有混合內容警告
- [ ] 資料傳輸加密

## 🎊 恭喜！

您已成功將Canva設計稿轉換為功能完整的網站並部署上線！

現在您可以：
1. 分享網址給老師和家長
2. 開始使用智慧點名功能
3. 為學生生成專屬QR碼
4. 享受數位化帶來的便利

如有任何問題，請參考故障排除章節或聯絡技術支援。

---

**部署成功範例**
- 網站網址：`https://your-site.netlify.app`
- 管理後台：`https://app.netlify.com/sites/your-site`
- 部署狀態：✅ 已上線

