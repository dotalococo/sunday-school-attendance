// QR碼生成器主要功能
let generatedQRCodes = JSON.parse(localStorage.getItem('generatedQRCodes')) || [];
let currentSingleQR = null;

// 頁面載入完成後初始化
document.addEventListener('DOMContentLoaded', function() {
    initializeQRGenerator();
    setupEventListeners();
    loadSavedQRCodes();
});

// 初始化QR碼生成器
function initializeQRGenerator() {
    console.log('QR碼生成器已載入');
    
    // 檢查QRCode庫是否載入
    if (typeof QRCode === 'undefined') {
        showMessage('QR碼生成庫載入失敗，請重新整理頁面', 'error');
        return;
    }
    
    console.log('QRCode庫載入成功');
}

// 設定事件監聽器
function setupEventListeners() {
    // 單個學生表單提交
    const singleStudentForm = document.getElementById('singleStudentForm');
    if (singleStudentForm) {
        singleStudentForm.addEventListener('submit', handleSingleStudentSubmit);
    }
    
    // 檔案匯入
    const importFileInput = document.getElementById('importFileInput');
    if (importFileInput) {
        importFileInput.addEventListener('change', handleFileImport);
    }
}

// 處理單個學生表單提交
function handleSingleStudentSubmit(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const studentData = {
        id: formData.get('studentId').trim(),
        name: formData.get('studentName').trim(),
        class: formData.get('studentClass'),
        grade: formData.get('studentGrade').trim(),
        timestamp: new Date().toISOString()
    };
    
    // 驗證必填欄位
    if (!studentData.id || !studentData.name) {
        showMessage('請填寫學生編號和姓名', 'error');
        return;
    }
    
    // 檢查是否已存在
    const existingQR = generatedQRCodes.find(qr => qr.id === studentData.id);
    if (existingQR) {
        if (!confirm(`學生編號 ${studentData.id} 已存在，是否要覆蓋？`)) {
            return;
        }
        // 移除舊的記錄
        generatedQRCodes = generatedQRCodes.filter(qr => qr.id !== studentData.id);
    }
    
    // 生成QR碼
    generateSingleQRCode(studentData);
}

// 生成單個QR碼
function generateSingleQRCode(studentData) {
    try {
        // 建立QR碼資料
        const qrData = {
            type: 'student_attendance',
            student_id: studentData.id,
            name: studentData.name,
            class: studentData.class,
            grade: studentData.grade,
            timestamp: studentData.timestamp
        };
        
        const qrString = JSON.stringify(qrData);
        
        // 生成QR碼
        const canvas = document.getElementById('singleQRCanvas');
        QRCode.toCanvas(canvas, qrString, {
            width: 200,
            height: 200,
            colorDark: '#333333',
            colorLight: '#FFFFFF',
            correctLevel: QRCode.CorrectLevel.M
        }, function(error) {
            if (error) {
                console.error('QR碼生成失敗:', error);
                showMessage('QR碼生成失敗', 'error');
                return;
            }
            
            // 顯示結果
            displaySingleQRResult(studentData, qrString);
            
            // 儲存到記錄
            const qrRecord = {
                ...studentData,
                qrData: qrString,
                canvas: canvas.toDataURL()
            };
            
            generatedQRCodes.push(qrRecord);
            localStorage.setItem('generatedQRCodes', JSON.stringify(generatedQRCodes));
            currentSingleQR = qrRecord;
            
            showMessage(`${studentData.name} 的QR碼生成成功！`, 'success');
            
            // 更新管理列表
            loadSavedQRCodes();
        });
        
    } catch (error) {
        console.error('生成QR碼時發生錯誤:', error);
        showMessage('生成QR碼時發生錯誤', 'error');
    }
}

// 顯示單個QR碼結果
function displaySingleQRResult(studentData, qrData) {
    const resultDiv = document.getElementById('singleQRResult');
    const studentNameEl = resultDiv.querySelector('.student-name');
    const studentIdEl = resultDiv.querySelector('.student-id');
    
    if (studentNameEl) studentNameEl.textContent = `姓名：${studentData.name}`;
    if (studentIdEl) studentIdEl.textContent = `編號：${studentData.id}`;
    
    resultDiv.style.display = 'block';
    resultDiv.scrollIntoView({ behavior: 'smooth' });
}

// 下載單個QR碼
function downloadSingleQR() {
    if (!currentSingleQR) {
        showMessage('沒有可下載的QR碼', 'error');
        return;
    }
    
    const canvas = document.getElementById('singleQRCanvas');
    const link = document.createElement('a');
    link.download = `QR_${currentSingleQR.name}_${currentSingleQR.id}.png`;
    link.href = canvas.toDataURL();
    link.click();
    
    showMessage('QR碼已下載', 'success');
}

// 列印單個QR碼
function printSingleQR() {
    if (!currentSingleQR) {
        showMessage('沒有可列印的QR碼', 'error');
        return;
    }
    
    const canvas = document.getElementById('singleQRCanvas');
    const printWindow = window.open('', '_blank');
    printWindow.document.write(`
        <html>
        <head>
            <title>列印QR碼 - ${currentSingleQR.name}</title>
            <style>
                body { 
                    font-family: Arial, sans-serif; 
                    text-align: center; 
                    padding: 20px; 
                }
                .qr-print {
                    border: 2px solid #333;
                    padding: 20px;
                    margin: 20px auto;
                    width: fit-content;
                    border-radius: 10px;
                }
                .student-info {
                    margin: 15px 0;
                    font-size: 18px;
                    font-weight: bold;
                }
                .qr-code {
                    margin: 15px 0;
                }
                .instructions {
                    margin-top: 20px;
                    font-size: 14px;
                    color: #666;
                }
            </style>
        </head>
        <body>
            <div class="qr-print">
                <h2>聖谷兒童主日學</h2>
                <div class="student-info">
                    <div>姓名：${currentSingleQR.name}</div>
                    <div>編號：${currentSingleQR.id}</div>
                    ${currentSingleQR.class ? `<div>班級：${currentSingleQR.class}</div>` : ''}
                </div>
                <div class="qr-code">
                    <img src="${canvas.toDataURL()}" alt="QR碼">
                </div>
                <div class="instructions">
                    請妥善保管此QR碼，用於主日學點名
                </div>
            </div>
        </body>
        </html>
    `);
    printWindow.document.close();
    printWindow.print();
}

// 批量生成QR碼
function generateBatchQR() {
    const batchData = document.getElementById('batchStudentData').value.trim();
    
    if (!batchData) {
        showMessage('請輸入學生資料', 'error');
        return;
    }
    
    const lines = batchData.split('\n').filter(line => line.trim());
    const students = [];
    const errors = [];
    
    // 解析資料
    lines.forEach((line, index) => {
        const parts = line.split(',').map(part => part.trim());
        
        if (parts.length < 2) {
            errors.push(`第 ${index + 1} 行：格式錯誤，至少需要編號和姓名`);
            return;
        }
        
        const student = {
            id: parts[0],
            name: parts[1],
            class: parts[2] || '',
            grade: parts[3] || '',
            timestamp: new Date().toISOString()
        };
        
        if (!student.id || !student.name) {
            errors.push(`第 ${index + 1} 行：編號或姓名不能為空`);
            return;
        }
        
        students.push(student);
    });
    
    if (errors.length > 0) {
        showMessage(`發現 ${errors.length} 個錯誤：\n${errors.join('\n')}`, 'error');
        return;
    }
    
    if (students.length === 0) {
        showMessage('沒有有效的學生資料', 'error');
        return;
    }
    
    // 開始批量生成
    generateBatchQRCodes(students);
}

// 批量生成QR碼
async function generateBatchQRCodes(students) {
    const batchResult = document.getElementById('batchQRResult');
    const batchGrid = document.getElementById('batchQRGrid');
    const batchCount = document.getElementById('batchCount');
    
    batchResult.style.display = 'block';
    batchGrid.innerHTML = '';
    
    let successCount = 0;
    const batchQRData = [];
    
    for (let i = 0; i < students.length; i++) {
        const student = students[i];
        
        try {
            // 檢查是否已存在
            const existingIndex = generatedQRCodes.findIndex(qr => qr.id === student.id);
            if (existingIndex !== -1) {
                generatedQRCodes.splice(existingIndex, 1);
            }
            
            // 建立QR碼資料
            const qrData = {
                type: 'student_attendance',
                student_id: student.id,
                name: student.name,
                class: student.class,
                grade: student.grade,
                timestamp: student.timestamp
            };
            
            const qrString = JSON.stringify(qrData);
            
            // 建立canvas
            const canvas = document.createElement('canvas');
            
            await new Promise((resolve, reject) => {
                QRCode.toCanvas(canvas, qrString, {
                    width: 150,
                    height: 150,
                    colorDark: '#333333',
                    colorLight: '#FFFFFF',
                    correctLevel: QRCode.CorrectLevel.M
                }, function(error) {
                    if (error) {
                        reject(error);
                        return;
                    }
                    
                    // 建立QR碼卡片
                    const qrCard = document.createElement('div');
                    qrCard.className = 'qr-card';
                    qrCard.innerHTML = `
                        <div class="qr-card-header">
                            <h4>${student.name}</h4>
                            <p>${student.id}</p>
                            ${student.class ? `<p>${student.class}</p>` : ''}
                        </div>
                        <div class="qr-card-body">
                            <canvas width="150" height="150"></canvas>
                        </div>
                        <div class="qr-card-actions">
                            <button onclick="downloadQRCard('${student.id}')" class="btn-sm">下載</button>
                        </div>
                    `;
                    
                    // 複製canvas內容
                    const cardCanvas = qrCard.querySelector('canvas');
                    const ctx = cardCanvas.getContext('2d');
                    ctx.drawImage(canvas, 0, 0);
                    
                    batchGrid.appendChild(qrCard);
                    
                    // 儲存記錄
                    const qrRecord = {
                        ...student,
                        qrData: qrString,
                        canvas: canvas.toDataURL()
                    };
                    
                    generatedQRCodes.push(qrRecord);
                    batchQRData.push(qrRecord);
                    successCount++;
                    
                    resolve();
                });
            });
            
        } catch (error) {
            console.error(`生成 ${student.name} 的QR碼失敗:`, error);
        }
        
        // 更新進度
        batchCount.textContent = successCount;
    }
    
    // 儲存到localStorage
    localStorage.setItem('generatedQRCodes', JSON.stringify(generatedQRCodes));
    
    showMessage(`批量生成完成！成功生成 ${successCount} 個QR碼`, 'success');
    
    // 更新管理列表
    loadSavedQRCodes();
    
    // 滾動到結果
    batchResult.scrollIntoView({ behavior: 'smooth' });
}

// 下載QR碼卡片
function downloadQRCard(studentId) {
    const qrRecord = generatedQRCodes.find(qr => qr.id === studentId);
    if (!qrRecord) {
        showMessage('找不到QR碼資料', 'error');
        return;
    }
    
    const link = document.createElement('a');
    link.download = `QR_${qrRecord.name}_${qrRecord.id}.png`;
    link.href = qrRecord.canvas;
    link.click();
}

// 下載全部QR碼
function downloadAllQR() {
    if (generatedQRCodes.length === 0) {
        showMessage('沒有可下載的QR碼', 'error');
        return;
    }
    
    // 建立ZIP檔案（簡化版本，實際可使用JSZip庫）
    generatedQRCodes.forEach(qr => {
        setTimeout(() => {
            const link = document.createElement('a');
            link.download = `QR_${qr.name}_${qr.id}.png`;
            link.href = qr.canvas;
            link.click();
        }, 100);
    });
    
    showMessage(`開始下載 ${generatedQRCodes.length} 個QR碼`, 'success');
}

// 列印全部QR碼
function printAllQR() {
    if (generatedQRCodes.length === 0) {
        showMessage('沒有可列印的QR碼', 'error');
        return;
    }
    
    const printWindow = window.open('', '_blank');
    let printContent = `
        <html>
        <head>
            <title>批量列印QR碼</title>
            <style>
                body { 
                    font-family: Arial, sans-serif; 
                    margin: 0; 
                    padding: 20px; 
                }
                .qr-grid {
                    display: grid;
                    grid-template-columns: repeat(3, 1fr);
                    gap: 20px;
                    page-break-inside: avoid;
                }
                .qr-item {
                    border: 2px solid #333;
                    padding: 15px;
                    text-align: center;
                    border-radius: 8px;
                    page-break-inside: avoid;
                }
                .qr-item h3 {
                    margin: 0 0 10px 0;
                    font-size: 16px;
                }
                .qr-item p {
                    margin: 5px 0;
                    font-size: 14px;
                }
                .qr-item img {
                    margin: 10px 0;
                }
                @media print {
                    .qr-grid {
                        grid-template-columns: repeat(2, 1fr);
                    }
                }
            </style>
        </head>
        <body>
            <h1>聖谷兒童主日學 - QR碼清單</h1>
            <div class="qr-grid">
    `;
    
    generatedQRCodes.forEach(qr => {
        printContent += `
            <div class="qr-item">
                <h3>${qr.name}</h3>
                <p>編號：${qr.id}</p>
                ${qr.class ? `<p>班級：${qr.class}</p>` : ''}
                <img src="${qr.canvas}" alt="QR碼" width="120" height="120">
            </div>
        `;
    });
    
    printContent += `
            </div>
        </body>
        </html>
    `;
    
    printWindow.document.write(printContent);
    printWindow.document.close();
    printWindow.print();
}

// 載入已儲存的QR碼
function loadSavedQRCodes() {
    const savedQRList = document.getElementById('savedQRList');
    
    if (generatedQRCodes.length === 0) {
        savedQRList.innerHTML = '<p>尚未生成任何QR碼</p>';
        return;
    }
    
    let listHTML = `
        <div class="saved-qr-header">
            <h4>已生成的QR碼 (${generatedQRCodes.length} 個)</h4>
        </div>
        <div class="saved-qr-grid">
    `;
    
    generatedQRCodes.forEach((qr, index) => {
        listHTML += `
            <div class="saved-qr-item">
                <div class="qr-thumbnail">
                    <img src="${qr.canvas}" alt="QR碼" width="60" height="60">
                </div>
                <div class="qr-details">
                    <h5>${qr.name}</h5>
                    <p>編號：${qr.id}</p>
                    ${qr.class ? `<p>班級：${qr.class}</p>` : ''}
                    <p>生成時間：${new Date(qr.timestamp).toLocaleDateString('zh-TW')}</p>
                </div>
                <div class="qr-actions">
                    <button onclick="downloadQRCard('${qr.id}')" class="btn-sm">下載</button>
                    <button onclick="deleteQRCode(${index})" class="btn-sm btn-danger">刪除</button>
                </div>
            </div>
        `;
    });
    
    listHTML += '</div>';
    savedQRList.innerHTML = listHTML;
}

// 刪除QR碼
function deleteQRCode(index) {
    if (confirm('確定要刪除這個QR碼嗎？')) {
        generatedQRCodes.splice(index, 1);
        localStorage.setItem('generatedQRCodes', JSON.stringify(generatedQRCodes));
        loadSavedQRCodes();
        showMessage('QR碼已刪除', 'success');
    }
}

// 清除單個表單
function clearSingleForm() {
    document.getElementById('singleStudentForm').reset();
    document.getElementById('singleQRResult').style.display = 'none';
    currentSingleQR = null;
}

// 清除批量資料
function clearBatchData() {
    document.getElementById('batchStudentData').value = '';
    document.getElementById('batchQRResult').style.display = 'none';
}

// 下載批量範本
function downloadBatchTemplate() {
    const template = `學生編號,姓名,班級,年級
SS001,王小明,幼幼班,小班
SS002,李小華,幼稚班,大班
SS003,張小美,小學低年級,小一
SS004,陳小強,小學中年級,小三
SS005,林小花,小學高年級,小五`;
    
    const blob = new Blob([template], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = '學生資料範本.csv';
    link.click();
    
    showMessage('範本已下載', 'success');
}

// 匯出QR碼資料
function exportQRData() {
    if (generatedQRCodes.length === 0) {
        showMessage('沒有可匯出的資料', 'error');
        return;
    }
    
    const exportData = {
        exportDate: new Date().toISOString(),
        totalCount: generatedQRCodes.length,
        qrCodes: generatedQRCodes
    };
    
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { 
        type: 'application/json;charset=utf-8;' 
    });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `QR碼資料_${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    
    showMessage('資料已匯出', 'success');
}

// 匯入QR碼資料
function importQRData() {
    document.getElementById('importFileInput').click();
}

// 處理檔案匯入
function handleFileImport(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = function(e) {
        try {
            const importData = JSON.parse(e.target.result);
            
            if (!importData.qrCodes || !Array.isArray(importData.qrCodes)) {
                showMessage('檔案格式錯誤', 'error');
                return;
            }
            
            if (confirm(`確定要匯入 ${importData.qrCodes.length} 個QR碼嗎？這將覆蓋現有資料。`)) {
                generatedQRCodes = importData.qrCodes;
                localStorage.setItem('generatedQRCodes', JSON.stringify(generatedQRCodes));
                loadSavedQRCodes();
                showMessage(`成功匯入 ${importData.qrCodes.length} 個QR碼`, 'success');
            }
            
        } catch (error) {
            console.error('匯入失敗:', error);
            showMessage('檔案格式錯誤或損壞', 'error');
        }
    };
    
    reader.readAsText(file);
    
    // 清除檔案輸入
    event.target.value = '';
}

// 清除全部QR碼資料
function clearAllQRData() {
    if (generatedQRCodes.length === 0) {
        showMessage('沒有資料可清除', 'info');
        return;
    }
    
    if (confirm(`確定要清除全部 ${generatedQRCodes.length} 個QR碼嗎？此操作無法復原。`)) {
        generatedQRCodes = [];
        localStorage.removeItem('generatedQRCodes');
        loadSavedQRCodes();
        clearSingleForm();
        clearBatchData();
        showMessage('全部資料已清除', 'success');
    }
}

// 顯示訊息（重用主頁面的函式）
function showMessage(message, type = 'info') {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message-toast ${type}`;
    messageDiv.textContent = message;
    
    messageDiv.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        background: ${type === 'success' ? '#28a745' : type === 'error' ? '#dc3545' : '#17a2b8'};
        color: white;
        padding: 15px 20px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 10000;
        max-width: 300px;
        animation: slideInRight 0.3s ease;
    `;
    
    document.body.appendChild(messageDiv);
    
    setTimeout(() => {
        messageDiv.style.animation = 'slideOutRight 0.3s ease';
        setTimeout(() => {
            if (messageDiv.parentNode) {
                messageDiv.parentNode.removeChild(messageDiv);
            }
        }, 300);
    }, 3000);
}

// 添加QR碼生成器專用的CSS樣式
const qrGeneratorStyle = document.createElement('style');
qrGeneratorStyle.textContent = `
    .qr-generator-section {
        padding: 2rem 0;
        min-height: calc(100vh - 140px);
    }
    
    .generator-container {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 2rem;
        margin-bottom: 3rem;
    }
    
    .generator-card {
        background: white;
        padding: 2rem;
        border-radius: 12px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }
    
    .generator-card h3 {
        color: var(--primary-purple);
        margin-bottom: 1.5rem;
        font-size: 1.3rem;
    }
    
    .form-row {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 1rem;
        margin-bottom: 1rem;
    }
    
    .qr-result {
        margin-top: 2rem;
        padding: 1.5rem;
        background: #f8f9fa;
        border-radius: 8px;
        text-align: center;
    }
    
    .qr-display {
        display: flex;
        align-items: center;
        gap: 1.5rem;
        justify-content: center;
        flex-wrap: wrap;
    }
    
    .qr-info {
        text-align: left;
    }
    
    .qr-actions {
        display: flex;
        gap: 0.5rem;
        margin-top: 1rem;
    }
    
    .batch-input textarea {
        width: 100%;
        padding: 1rem;
        border: 2px solid #e9ecef;
        border-radius: 8px;
        font-family: monospace;
        font-size: 14px;
        resize: vertical;
    }
    
    .batch-actions {
        display: flex;
        gap: 0.5rem;
        margin-top: 1rem;
        flex-wrap: wrap;
    }
    
    .batch-result {
        margin-top: 2rem;
        padding: 1.5rem;
        background: #f8f9fa;
        border-radius: 8px;
    }
    
    .batch-summary {
        text-align: center;
        font-size: 1.2rem;
        font-weight: bold;
        color: var(--primary-purple);
        margin-bottom: 1rem;
    }
    
    .qr-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
        gap: 1rem;
        margin-top: 1rem;
    }
    
    .qr-card {
        background: white;
        border: 1px solid #ddd;
        border-radius: 8px;
        padding: 1rem;
        text-align: center;
    }
    
    .qr-card-header h4 {
        margin: 0 0 0.5rem 0;
        color: var(--primary-purple);
    }
    
    .qr-card-header p {
        margin: 0.25rem 0;
        font-size: 0.9rem;
        color: #666;
    }
    
    .qr-card-body {
        margin: 1rem 0;
    }
    
    .qr-card-actions {
        margin-top: 1rem;
    }
    
    .management-section {
        background: white;
        padding: 2rem;
        border-radius: 12px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }
    
    .management-controls {
        display: flex;
        gap: 0.5rem;
        margin-bottom: 1.5rem;
        flex-wrap: wrap;
    }
    
    .saved-qr-grid {
        display: grid;
        gap: 1rem;
    }
    
    .saved-qr-item {
        display: flex;
        align-items: center;
        gap: 1rem;
        padding: 1rem;
        background: #f8f9fa;
        border-radius: 8px;
        border: 1px solid #e9ecef;
    }
    
    .qr-thumbnail img {
        border-radius: 4px;
        border: 1px solid #ddd;
    }
    
    .qr-details {
        flex: 1;
    }
    
    .qr-details h5 {
        margin: 0 0 0.5rem 0;
        color: var(--primary-purple);
    }
    
    .qr-details p {
        margin: 0.25rem 0;
        font-size: 0.9rem;
        color: #666;
    }
    
    .qr-actions {
        display: flex;
        gap: 0.5rem;
        flex-direction: column;
    }
    
    .btn-sm {
        padding: 0.5rem 1rem;
        font-size: 0.9rem;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        background: var(--primary-purple);
        color: white;
        transition: all 0.3s ease;
    }
    
    .btn-sm:hover {
        transform: translateY(-1px);
    }
    
    .btn-danger {
        background: #dc3545;
    }
    
    .btn-outline {
        background: transparent;
        border: 2px solid var(--primary-purple);
        color: var(--primary-purple);
        padding: 0.5rem 1rem;
        border-radius: 4px;
        cursor: pointer;
        transition: all 0.3s ease;
    }
    
    .btn-outline:hover {
        background: var(--primary-purple);
        color: white;
    }
    
    @media (max-width: 768px) {
        .generator-container {
            grid-template-columns: 1fr;
        }
        
        .form-row {
            grid-template-columns: 1fr;
        }
        
        .qr-display {
            flex-direction: column;
        }
        
        .qr-grid {
            grid-template-columns: 1fr;
        }
        
        .saved-qr-item {
            flex-direction: column;
            text-align: center;
        }
        
        .qr-actions {
            flex-direction: row;
            justify-content: center;
        }
    }
`;
document.head.appendChild(qrGeneratorStyle);

