// 全域變數
let qrScanner = null;
let currentCamera = 'environment';
let attendanceData = JSON.parse(localStorage.getItem('attendanceData')) || [];
let studentsData = JSON.parse(localStorage.getItem('studentsData')) || [];

// DOM載入完成後初始化
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
    setupEventListeners();
    loadAttendanceData();
    updateLeaderboard();
});

// 初始化應用程式
function initializeApp() {
    console.log('聖谷兒童主日學智慧系統已載入');
    
    // 檢查是否支援相機
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        console.warn('此瀏覽器不支援相機功能');
        showMessage('您的瀏覽器不支援相機功能，請使用較新的瀏覽器', 'error');
    }
    
    // 載入今日點名統計
    updateTodayStats();
}

// 設定事件監聽器
function setupEventListeners() {
    // 漢堡選單
    const hamburger = document.querySelector('.hamburger');
    const navMenu = document.querySelector('.nav-menu');
    
    if (hamburger && navMenu) {
        hamburger.addEventListener('click', function() {
            hamburger.classList.toggle('active');
            navMenu.classList.toggle('active');
        });
    }
    
    // 新學生表單提交
    const newStudentForm = document.getElementById('newStudentForm');
    if (newStudentForm) {
        newStudentForm.addEventListener('submit', handleNewStudentRegistration);
    }
    
    // 點數查詢
    const studentIdInput = document.getElementById('studentIdInput');
    if (studentIdInput) {
        studentIdInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                queryPoints();
            }
        });
    }
    
    // 平滑滾動
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

// 開始新朋友報到
function startRegistration() {
    const registrationForm = document.getElementById('registrationForm');
    if (registrationForm) {
        registrationForm.style.display = 'block';
        registrationForm.scrollIntoView({ behavior: 'smooth' });
        registrationForm.classList.add('fade-in-up');
    }
}

// 隱藏報到表單
function hideRegistrationForm() {
    const registrationForm = document.getElementById('registrationForm');
    if (registrationForm) {
        registrationForm.style.display = 'none';
    }
}

// 處理新學生報到
function handleNewStudentRegistration(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const studentData = {
        id: generateStudentId(),
        name: formData.get('studentName'),
        age: formData.get('studentAge'),
        parentName: formData.get('parentName'),
        parentPhone: formData.get('parentPhone'),
        emergencyContact: formData.get('emergencyContact'),
        registrationDate: new Date().toISOString(),
        points: 10, // 新生獎勵點數
        qrCode: null
    };
    
    // 驗證必填欄位
    if (!studentData.name || !studentData.parentName || !studentData.parentPhone) {
        showMessage('請填寫所有必填欄位', 'error');
        return;
    }
    
    // 生成QR碼
    studentData.qrCode = generateQRCodeData(studentData);
    
    // 儲存學生資料
    studentsData.push(studentData);
    localStorage.setItem('studentsData', JSON.stringify(studentsData));
    
    // 顯示成功訊息
    showMessage(`歡迎 ${studentData.name}！報到成功，獲得 10 點數獎勵`, 'success');
    
    // 重置表單並隱藏
    e.target.reset();
    hideRegistrationForm();
    
    // 更新統計
    updateLeaderboard();
    
    console.log('新學生報到成功:', studentData);
}

// 生成學生ID
function generateStudentId() {
    const timestamp = Date.now().toString(36);
    const random = Math.random().toString(36).substr(2, 5);
    return `SS${timestamp}${random}`.toUpperCase();
}

// 生成QR碼資料
function generateQRCodeData(studentData) {
    return JSON.stringify({
        type: 'student_attendance',
        student_id: studentData.id,
        name: studentData.name,
        timestamp: new Date().toISOString()
    });
}

// 開始點名掃描
function startAttendanceScanning() {
    const scannerContainer = document.getElementById('scannerContainer');
    if (!scannerContainer) return;
    
    scannerContainer.style.display = 'block';
    scannerContainer.scrollIntoView({ behavior: 'smooth' });
    
    initializeQRScanner();
}

// 初始化QR碼掃描器
async function initializeQRScanner() {
    try {
        const video = document.getElementById('qr-video');
        if (!video) return;
        
        // 檢查QR Scanner是否可用
        if (typeof QrScanner === 'undefined') {
            showScanResult('QR碼掃描器載入失敗，請重新整理頁面', 'error');
            return;
        }
        
        // 初始化掃描器
        qrScanner = new QrScanner(
            video,
            result => handleQRScanResult(result),
            {
                onDecodeError: error => {
                    console.log('掃描中...', error);
                },
                highlightScanRegion: true,
                highlightCodeOutline: true,
                preferredCamera: currentCamera
            }
        );
        
        await qrScanner.start();
        showScanResult('掃描器已啟動，請將QR碼對準掃描框', 'info');
        
    } catch (error) {
        console.error('啟動掃描器失敗:', error);
        showScanResult('無法啟動相機，請檢查權限設定', 'error');
    }
}

// 處理QR碼掃描結果
function handleQRScanResult(result) {
    try {
        const data = JSON.parse(result.data);
        
        if (data.type === 'student_attendance') {
            processAttendance(data);
        } else {
            showScanResult('無效的QR碼格式', 'error');
        }
        
    } catch (error) {
        // 如果不是JSON格式，嘗試作為學生ID處理
        processAttendanceByText(result.data);
    }
}

// 處理點名
function processAttendance(data) {
    const today = new Date().toDateString();
    const existingRecord = attendanceData.find(record => 
        record.student_id === data.student_id && 
        new Date(record.timestamp).toDateString() === today
    );
    
    if (existingRecord) {
        showScanResult(`${data.name} 今日已經點名過了`, 'error');
        return;
    }
    
    // 建立點名記錄
    const attendanceRecord = {
        student_id: data.student_id,
        name: data.name,
        timestamp: new Date().toISOString(),
        status: 'present'
    };
    
    attendanceData.push(attendanceRecord);
    localStorage.setItem('attendanceData', JSON.stringify(attendanceData));
    
    // 增加學生點數
    addPointsToStudent(data.student_id, 5);
    
    showScanResult(`${data.name} 點名成功！獲得 5 點數`, 'success');
    
    // 更新統計
    updateTodayStats();
    updateLeaderboard();
    
    console.log('點名成功:', attendanceRecord);
}

// 處理文字格式的點名
function processAttendanceByText(text) {
    const student = studentsData.find(s => s.id === text || s.name === text);
    
    if (student) {
        processAttendance({
            type: 'student_attendance',
            student_id: student.id,
            name: student.name
        });
    } else {
        showScanResult('找不到對應的學生資料', 'error');
    }
}

// 增加學生點數
function addPointsToStudent(studentId, points) {
    const student = studentsData.find(s => s.id === studentId);
    if (student) {
        student.points = (student.points || 0) + points;
        localStorage.setItem('studentsData', JSON.stringify(studentsData));
    }
}

// 顯示掃描結果
function showScanResult(message, type) {
    const scanResult = document.getElementById('scanResult');
    if (!scanResult) return;
    
    scanResult.textContent = message;
    scanResult.className = `scan-result ${type}`;
    
    // 3秒後清除訊息
    setTimeout(() => {
        scanResult.textContent = '';
        scanResult.className = 'scan-result';
    }, 3000);
}

// 停止掃描
function stopScanning() {
    if (qrScanner) {
        qrScanner.stop();
        qrScanner = null;
    }
    
    const scannerContainer = document.getElementById('scannerContainer');
    if (scannerContainer) {
        scannerContainer.style.display = 'none';
    }
}

// 切換相機
async function switchCamera() {
    if (!qrScanner) return;
    
    currentCamera = currentCamera === 'environment' ? 'user' : 'environment';
    
    try {
        await qrScanner.setCamera(currentCamera);
        showScanResult(`已切換到${currentCamera === 'environment' ? '後' : '前'}置相機`, 'info');
    } catch (error) {
        console.error('切換相機失敗:', error);
        showScanResult('切換相機失敗', 'error');
    }
}

// 查看點名記錄
function viewAttendanceRecords() {
    const today = new Date().toDateString();
    const todayRecords = attendanceData.filter(record => 
        new Date(record.timestamp).toDateString() === today
    );
    
    if (todayRecords.length === 0) {
        showMessage('今日尚無點名記錄', 'info');
        return;
    }
    
    let recordsHtml = '<h3>今日點名記錄</h3><ul>';
    todayRecords.forEach(record => {
        const time = new Date(record.timestamp).toLocaleTimeString('zh-TW');
        recordsHtml += `<li>${record.name} - ${time}</li>`;
    });
    recordsHtml += '</ul>';
    
    showModal('點名記錄', recordsHtml);
}

// 生成QR碼
function generateQRCode() {
    showModal('QR碼生成器', `
        <div class="qr-generator">
            <h3>為學生生成QR碼</h3>
            <select id="studentSelect">
                <option value="">請選擇學生</option>
                ${studentsData.map(student => 
                    `<option value="${student.id}">${student.name}</option>`
                ).join('')}
            </select>
            <button onclick="generateStudentQR()" class="btn-primary">生成QR碼</button>
            <div id="qrCodeDisplay"></div>
        </div>
    `);
}

// 生成學生QR碼
function generateStudentQR() {
    const studentSelect = document.getElementById('studentSelect');
    const studentId = studentSelect.value;
    
    if (!studentId) {
        showMessage('請選擇學生', 'error');
        return;
    }
    
    const student = studentsData.find(s => s.id === studentId);
    if (!student) {
        showMessage('找不到學生資料', 'error');
        return;
    }
    
    const qrData = generateQRCodeData(student);
    const qrCodeDisplay = document.getElementById('qrCodeDisplay');
    
    if (qrCodeDisplay) {
        qrCodeDisplay.innerHTML = `
            <div class="qr-code-result">
                <h4>${student.name} 的專屬QR碼</h4>
                <div class="qr-code-placeholder">
                    <p>QR碼資料：</p>
                    <textarea readonly>${qrData}</textarea>
                    <p>請使用QR碼生成器將此資料轉換為QR碼圖片</p>
                </div>
            </div>
        `;
    }
}

// 查詢點數
function queryPoints() {
    const studentIdInput = document.getElementById('studentIdInput');
    const studentId = studentIdInput.value.trim();
    
    if (!studentId) {
        showMessage('請輸入學生編號', 'error');
        return;
    }
    
    const student = studentsData.find(s => 
        s.id === studentId || s.name.includes(studentId)
    );
    
    const pointsResult = document.getElementById('pointsResult');
    
    if (student) {
        pointsResult.innerHTML = `
            <div class="points-display">
                <h4>${student.name}</h4>
                <div class="points-value">${student.points || 0} 點</div>
                <p>註冊日期：${new Date(student.registrationDate).toLocaleDateString('zh-TW')}</p>
            </div>
        `;
    } else {
        pointsResult.innerHTML = '<p>找不到對應的學生資料</p>';
    }
}

// 檢查點數（主按鈕功能）
function checkPoints() {
    document.getElementById('points').scrollIntoView({ behavior: 'smooth' });
}

// 更新排行榜
function updateLeaderboard() {
    const leaderboard = document.getElementById('leaderboard');
    if (!leaderboard) return;
    
    if (studentsData.length === 0) {
        leaderboard.innerHTML = '<p>尚無學生資料</p>';
        return;
    }
    
    const sortedStudents = [...studentsData]
        .sort((a, b) => (b.points || 0) - (a.points || 0))
        .slice(0, 10);
    
    let leaderboardHtml = '';
    sortedStudents.forEach((student, index) => {
        leaderboardHtml += `
            <div class="leaderboard-item">
                <span class="leaderboard-rank">#${index + 1}</span>
                <span class="leaderboard-name">${student.name}</span>
                <span class="leaderboard-points">${student.points || 0} 點</span>
            </div>
        `;
    });
    
    leaderboard.innerHTML = leaderboardHtml;
}

// 更新今日統計
function updateTodayStats() {
    const today = new Date().toDateString();
    const todayAttendance = attendanceData.filter(record => 
        new Date(record.timestamp).toDateString() === today
    );
    
    console.log(`今日點名人數：${todayAttendance.length}`);
}

// 載入點名資料
function loadAttendanceData() {
    // 從localStorage載入資料
    const savedAttendance = localStorage.getItem('attendanceData');
    const savedStudents = localStorage.getItem('studentsData');
    
    if (savedAttendance) {
        attendanceData = JSON.parse(savedAttendance);
    }
    
    if (savedStudents) {
        studentsData = JSON.parse(savedStudents);
    }
    
    console.log('已載入資料:', {
        attendance: attendanceData.length,
        students: studentsData.length
    });
}

// 顯示訊息
function showMessage(message, type = 'info') {
    // 建立訊息元素
    const messageDiv = document.createElement('div');
    messageDiv.className = `message-toast ${type}`;
    messageDiv.textContent = message;
    
    // 樣式
    messageDiv.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        background: ${type === 'success' ? '#28a745' : type === 'error' ? '#dc3545' : '#17a2b8'};
        color: white;
        padding: 15px 20px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 10000;
        max-width: 300px;
        animation: slideInRight 0.3s ease;
    `;
    
    document.body.appendChild(messageDiv);
    
    // 3秒後移除
    setTimeout(() => {
        messageDiv.style.animation = 'slideOutRight 0.3s ease';
        setTimeout(() => {
            if (messageDiv.parentNode) {
                messageDiv.parentNode.removeChild(messageDiv);
            }
        }, 300);
    }, 3000);
}

// 顯示模態框
function showModal(title, content) {
    const modal = document.createElement('div');
    modal.className = 'modal-overlay';
    modal.innerHTML = `
        <div class="modal-content">
            <div class="modal-header">
                <h3>${title}</h3>
                <button class="modal-close" onclick="closeModal()">&times;</button>
            </div>
            <div class="modal-body">
                ${content}
            </div>
        </div>
    `;
    
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.5);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 10000;
    `;
    
    document.body.appendChild(modal);
    window.currentModal = modal;
}

// 關閉模態框
function closeModal() {
    if (window.currentModal) {
        document.body.removeChild(window.currentModal);
        window.currentModal = null;
    }
}

// 老師登入
function showTeacherLogin() {
    showModal('老師登入', `
        <div class="teacher-login">
            <div class="form-group">
                <label>教師編號：</label>
                <input type="text" id="teacherId" placeholder="請輸入教師編號">
            </div>
            <div class="form-group">
                <label>密碼：</label>
                <input type="password" id="teacherPassword" placeholder="請輸入密碼">
            </div>
            <button onclick="processTeacherLogin()" class="btn-primary">登入</button>
        </div>
    `);
}

// 處理老師登入
function processTeacherLogin() {
    const teacherId = document.getElementById('teacherId').value;
    const password = document.getElementById('teacherPassword').value;
    
    // 簡單的驗證（實際應用中應該使用更安全的方式）
    if (teacherId === 'teacher' && password === '123456') {
        showMessage('登入成功！', 'success');
        closeModal();
        // 這裡可以顯示管理功能
    } else {
        showMessage('帳號或密碼錯誤', 'error');
    }
}

// 添加CSS動畫
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    
    @keyframes slideOutRight {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
    }
    
    .modal-content {
        background: white;
        border-radius: 12px;
        max-width: 500px;
        width: 90%;
        max-height: 80vh;
        overflow-y: auto;
    }
    
    .modal-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 20px;
        border-bottom: 1px solid #eee;
    }
    
    .modal-close {
        background: none;
        border: none;
        font-size: 24px;
        cursor: pointer;
        color: #999;
    }
    
    .modal-body {
        padding: 20px;
    }
    
    .points-display {
        text-align: center;
        padding: 20px;
        background: #f8f9fa;
        border-radius: 8px;
    }
    
    .points-value {
        font-size: 2rem;
        font-weight: bold;
        color: #8B7ED8;
        margin: 10px 0;
    }
    
    .qr-code-placeholder textarea {
        width: 100%;
        height: 100px;
        margin: 10px 0;
        padding: 10px;
        border: 1px solid #ddd;
        border-radius: 4px;
        font-family: monospace;
        font-size: 12px;
    }
`;
document.head.appendChild(style);

